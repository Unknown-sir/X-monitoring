from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
from functools import wraps
import requests

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Set a unique secret key for session security

# Database initialization
def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users 
                 (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT, active INTEGER DEFAULT 1)''')
    c.execute('''CREATE TABLE IF NOT EXISTS servers 
                 (id INTEGER PRIMARY KEY, name TEXT, ip TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS user_servers 
                 (user_id INTEGER, server_id INTEGER)''')
    # Default admin user
    c.execute("INSERT OR IGNORE INTO users (username, password, role, active) VALUES (?, ?, ?, ?)", 
              ('admin', 'admin123', 'admin', 1))
    conn.commit()
    conn.close()

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Admin required decorator
def admin_required(f):
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if session['role'] != 'admin':
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

# Login page
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=? AND active=1", (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['user_id'] = user[0]
            session['role'] = user[3]
            return redirect(url_for('dashboard'))
    return render_template('login.html')

# Dashboard
@app.route('/dashboard')
@login_required
def dashboard():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    if session['role'] == 'admin':
        c.execute("SELECT * FROM servers")
        servers = c.fetchall()
        c.execute("SELECT id, username, role, active FROM users")
        users = c.fetchall()
        c.execute("SELECT id, name FROM servers")
        all_servers = c.fetchall()  # For server assignment dropdown
    else:
        c.execute("SELECT s.id, s.name, s.ip FROM servers s JOIN user_servers us ON s.id = us.server_id WHERE us.user_id=?", 
                  (session['user_id'],))
        servers = c.fetchall()
        users = []
        all_servers = []
    conn.close()
    return render_template('dashboard.html', servers=servers, role=session['role'], users=users, all_servers=all_servers)

# Add new server (admin only)
@app.route('/add_server', methods=['POST'])
@admin_required
def add_server():
    name = request.form['name']
    ip = request.form['ip']
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("INSERT INTO servers (name, ip) VALUES (?, ?)", (name, ip))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

# Add new user (admin only)
@app.route('/add_user', methods=['POST'])
@admin_required
def add_user():
    username = request.form['username']
    password = request.form['password']
    role = request.form['role']
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("INSERT INTO users (username, password, role, active) VALUES (?, ?, ?, 1)", (username, password, role))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

# Edit user (admin only)
@app.route('/edit_user/<int:user_id>', methods=['POST'])
@admin_required
def edit_user(user_id):
    username = request.form['username']
    password = request.form['password']
    role = request.form['role']
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("UPDATE users SET username=?, password=?, role=? WHERE id=?", (username, password, role, user_id))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

# Delete user (admin only)
@app.route('/delete_user/<int:user_id>')
@admin_required
def delete_user(user_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("DELETE FROM users WHERE id=?", (user_id,))
    c.execute("DELETE FROM user_servers WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

# Disable/Enable user (admin only)
@app.route('/toggle_user/<int:user_id>')
@admin_required
def toggle_user(user_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT active FROM users WHERE id=?", (user_id,))
    current_status = c.fetchone()[0]
    new_status = 0 if current_status == 1 else 1
    c.execute("UPDATE users SET active=? WHERE id=?", (new_status, user_id))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

# Assign server to user (admin only)
@app.route('/assign_server', methods=['POST'])
@admin_required
def assign_server():
    user_id = request.form['user_id']
    server_id = request.form['server_id']
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO user_servers (user_id, server_id) VALUES (?, ?)", (user_id, server_id))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

# Display port 5000 content
@app.route('/live/<int:server_id>')
@login_required
def live_port(server_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT ip FROM servers WHERE id=?", (server_id,))
    server = c.fetchone()
    conn.close()
    if server:
        ip = server[0]
        url = f"http://{ip}:5000"
        return render_template('live_port.html', server_url=url)
    return "Server not found", 404

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000)