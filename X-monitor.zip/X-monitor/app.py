from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
from functools import wraps
import paramiko
import logging
import threading
import time
import subprocess
import smtplib
from email.mime.text import MIMEText
import redis
import pickle
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Set a unique secret key for session security

# Setup logging
logging.basicConfig(filename='app.log', level=logging.DEBUG,
                    format='%(asctime)s %(levelname)s: %(message)s')

# Redis cache
cache = redis.Redis(host='localhost', port=6379, db=0)

# Telegram Bot setup
TELEGRAM_TOKEN = '7922676385:AAH6bcQC47QvqjKddesh52sQ5GjaZ7KTpV0'  # Your bot token
ADMIN_CHAT_ID = '5961740775'  # Default admin chat ID

# Email setup (replace with your SMTP details)
EMAIL_FROM = 'MS_zXMWXI@trial-vywj2lp8wjpg7oqz.mlsender.net'
EMAIL_PASSWORD = 'mssp.g4KHczw.351ndgwqo7rgzqx8.fJKuEUi'
SMTP_SERVER = 'smtp.mailersend.net'
SMTP_PORT = 587

# Database initialization
def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT, telegram_chat_id TEXT, active INTEGER DEFAULT 1)''')
    c.execute('''CREATE TABLE IF NOT EXISTS servers
                 (id INTEGER PRIMARY KEY, name TEXT, ip TEXT, username TEXT, password TEXT, traffic_limit INTEGER DEFAULT 0, telegram_chat_id TEXT, active INTEGER DEFAULT 1)''')
    c.execute('''CREATE TABLE IF NOT EXISTS user_servers
                 (user_id INTEGER, server_id INTEGER)''')
    # Default admin user
    c.execute("INSERT OR IGNORE INTO users (username, password, role, telegram_chat_id, active) VALUES (?, ?, ?, ?, ?)",
              ('admin', 'admin123', 'admin', '5961740775', 1))
    conn.commit()
    conn.close()

# Send email function
def send_email(subject, body, to_email='admin@example.com'):
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = EMAIL_FROM
    msg['To'] = to_email
    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(EMAIL_FROM, EMAIL_PASSWORD)
            server.send_message(msg)
            logging.info(f"Email sent to {to_email}: {subject}")
    except Exception as e:
        logging.error(f"Failed to send email: {str(e)}")

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Admin required decorator
def admin_required(f):
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if session['role'] != 'admin':
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

# Login page
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=? AND active=1", (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['user_id'] = user[0]
            session['role'] = user[3]
            return redirect(url_for('dashboard'))
    return render_template('login.html')

# Logout
@app.route('/logout')
@login_required
def logout():
    session.pop('user_id', None)
    session.pop('role', None)
    return redirect(url_for('login'))

# Profile page
@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        telegram_chat_id = request.form['telegram_chat_id']
        password = request.form['password']
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("UPDATE users SET telegram_chat_id=?, password=? WHERE id=?",
                  (telegram_chat_id, password, session['user_id']))
        conn.commit()
        conn.close()
        return redirect(url_for('dashboard'))
    return render_template('profile.html')

# Dashboard (server boxes for all users)
@app.route('/dashboard')
@login_required
def dashboard():
    cached_servers = cache.get('servers')
    if cached_servers:
        servers = pickle.loads(cached_servers)
    else:
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        if session['role'] == 'admin':
            c.execute("SELECT id, name, ip FROM servers WHERE active=1")
            servers = c.fetchall()
        else:
            c.execute("SELECT s.id, s.name, s.ip FROM servers s JOIN user_servers us ON s.id = us.server_id WHERE us.user_id=? AND s.active=1",
                      (session['user_id'],))
            servers = c.fetchall()
        conn.close()
        cache.setex('servers', 300, pickle.dumps(servers))  # Cache for 5 minutes
    return render_template('dashboard.html', servers=servers, role=session['role'])

# Admin Dashboard
@app.route('/admin_dashboard')
@admin_required
def admin_dashboard():
    return render_template('admin_dashboard.html')

# Add Server Page
@app.route('/add_server', methods=['GET', 'POST'])
@admin_required
def add_server_page():
    if request.method == 'POST':
        name = request.form['name']
        ip = request.form['ip']
        username = request.form['username']
        password = request.form['password']
        traffic_limit = request.form.get('traffic_limit', 0)
        telegram_chat_id = request.form.get('telegram_chat_id', '')
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("INSERT INTO servers (name, ip, username, password, traffic_limit, telegram_chat_id, active) VALUES (?, ?, ?, ?, ?, ?, 1)",
                  (name, ip, username, password, traffic_limit, telegram_chat_id))
        conn.commit()
        conn.close()
        cache.delete('servers')  # Clear cache
        return redirect(url_for('admin_dashboard'))
    return render_template('add_server.html')

# Add User Page
@app.route('/add_user', methods=['GET', 'POST'])
@admin_required
def add_user_page():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        telegram_chat_id = request.form.get('telegram_chat_id', '')
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("INSERT INTO users (username, password, role, telegram_chat_id, active) VALUES (?, ?, ?, ?, 1)",
                  (username, password, role, telegram_chat_id))
        conn.commit()
        conn.close()
        return redirect(url_for('admin_dashboard'))
    return render_template('add_user.html')

# Assign Server Page
@app.route('/assign_server', methods=['GET', 'POST'])
@admin_required
def assign_server_page():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT id, username FROM users WHERE active=1")
    users = c.fetchall()
    c.execute("SELECT id, name FROM servers WHERE active=1")
    servers = c.fetchall()
    conn.close()
    if request.method == 'POST':
        user_id = request.form['user_id']
        server_id = request.form['server_id']
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("INSERT OR IGNORE INTO user_servers (user_id, server_id) VALUES (?, ?)", (user_id, server_id))
        conn.commit()
        conn.close()
        cache.delete('servers')  # Clear cache
        return redirect(url_for('admin_dashboard'))
    return render_template('assign_server.html', users=users, servers=servers)

# Manage Servers Page
@app.route('/manage_servers', methods=['GET', 'POST'])
@admin_required
def manage_servers():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT * FROM servers")
    servers = c.fetchall()
    conn.close()
    if request.method == 'POST' and 'edit_server_id' in request.form:
        server_id = request.form['edit_server_id']
        name = request.form['name']
        ip = request.form['ip']
        username = request.form['username']
        password = request.form['password']
        traffic_limit = request.form.get('traffic_limit', 0)
        telegram_chat_id = request.form.get('telegram_chat_id', '')
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("UPDATE servers SET name=?, ip=?, username=?, password=?, traffic_limit=?, telegram_chat_id=? WHERE id=?",
                  (name, ip, username, password, traffic_limit, telegram_chat_id, server_id))
        conn.commit()
        conn.close()
        cache.delete('servers')  # Clear cache
        return redirect(url_for('manage_servers'))
    return render_template('manage_servers.html', servers=servers)

# Reset Traffic
@app.route('/reset_traffic/<int:server_id>')
@admin_required
def reset_traffic(server_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT ip, username, password FROM servers WHERE id=?", (server_id,))
    server = c.fetchone()
    conn.close()
    if server:
        ip, username, password = server
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(ip, username=username, password=password, timeout=10)
            ssh.exec_command("vnstat -i ens34 --reset")
            ssh.close()
            logging.info(f"Traffic reset for server {ip}")
        except Exception as e:
            logging.error(f"Failed to reset traffic for {ip}: {str(e)}")
    cache.delete('servers')  # Clear cache
    return redirect(url_for('manage_servers'))

# Manage Users Page
@app.route('/manage_users', methods=['GET', 'POST'])
@admin_required
def manage_users():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT id, username, role, telegram_chat_id, active FROM users")
    users = c.fetchall()
    conn.close()
    if request.method == 'POST' and 'edit_user_id' in request.form:
        user_id = request.form['edit_user_id']
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        telegram_chat_id = request.form.get('telegram_chat_id', '')
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("UPDATE users SET username=?, password=?, role=?, telegram_chat_id=? WHERE id=?",
                  (username, password, role, telegram_chat_id, user_id))
        conn.commit()
        conn.close()
        return redirect(url_for('manage_users'))
    return render_template('manage_users.html', users=users)

# Toggle server active status (admin only)
@app.route('/toggle_server/<int:server_id>')
@admin_required
def toggle_server(server_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT active FROM servers WHERE id=?", (server_id,))
    current_status = c.fetchone()[0]
    new_status = 0 if current_status == 1 else 1
    c.execute("UPDATE servers SET active=? WHERE id=?", (new_status, server_id))
    conn.commit()
    conn.close()
    cache.delete('servers')  # Clear cache
    return redirect(url_for('manage_servers'))

# Delete user (admin only)
@app.route('/delete_user/<int:user_id>')
@admin_required
def delete_user(user_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("DELETE FROM users WHERE id=?", (user_id,))
    c.execute("DELETE FROM user_servers WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('manage_users'))

# Disable/Enable user (admin only)
@app.route('/toggle_user/<int:user_id>')
@admin_required
def toggle_user(user_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT active FROM users WHERE id=?", (user_id,))
    current_status = c.fetchone()[0]
    new_status = 0 if current_status == 1 else 1
    c.execute("UPDATE users SET active=? WHERE id=?", (new_status, user_id))
    conn.commit()
    conn.close()
    return redirect(url_for('manage_users'))

# Display server monitoring page
@app.route('/live/<int:server_id>')
@login_required
def live_port(server_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT ip, username, password, traffic_limit FROM servers WHERE id=?", (server_id,))
    server = c.fetchone()
    conn.close()
    if server:
        return render_template('live_port.html', server_id=server_id)
    return "Server not found", 404

# Get server monitoring data via SSH
@app.route('/monitor/<int:server_id>')
@login_required
def monitor_server(server_id):
    logging.info(f"Request received for monitoring server ID: {server_id}")
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT ip, username, password, traffic_limit, telegram_chat_id FROM servers WHERE id=?", (server_id,))
    server = c.fetchone()
    conn.close()
    if server:
        ip, username, password, traffic_limit, telegram_chat_id = server
        logging.info(f"Connecting to server {ip} with username {username}")
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(ip, username=username, password=password, timeout=10)
            logging.info("SSH connection established")

            # CPU
            stdin, stdout, stderr = ssh.exec_command("nproc")
            total_cpu = int(stdout.read().decode().strip())
            stdin, stdout, stderr = ssh.exec_command("top -bn1 | grep 'Cpu(s)' | awk '{print $2}'")
            cpu_output = stdout.read().decode().strip()
            cpu_usage = float(cpu_output) if cpu_output else 0.0

            # RAM
            stdin, stdout, stderr = ssh.exec_command("free -m | awk '/Mem:/ {print $2}'")
            total_ram = int(stdout.read().decode().strip())
            stdin, stdout, stderr = ssh.exec_command("free -m | awk '/Mem:/ {print $3/$2 * 100}'")
            ram_output = stdout.read().decode().strip()
            ram_usage = float(ram_output) if ram_output else 0.0

            # Network
            stdin, stdout, stderr = ssh.exec_command("vnstat -tr 2 -i ens34 | grep 'rx' | awk '{print $2}'")
            download_output = stdout.read().decode().strip()
            download = float(download_output) / 8 if download_output and download_output != "Not enough data available yet." else 0.0
            stdin, stdout, stderr = ssh.exec_command("vnstat -tr 2 -i ens34 | grep 'tx' | awk '{print $2}'")
            upload_output = stdout.read().decode().strip()
            upload = float(upload_output) / 8 if upload_output and upload_output != "Not enough data available yet." else 0.0
            total_network = upload + download

            # Disk
            stdin, stdout, stderr = ssh.exec_command("df -h / | awk 'NR==2 {print $2}'")  # Total disk size in human-readable (e.g., "100G")
            total_disk_output = stdout.read().decode().strip()
            total_disk = float(total_disk_output.rstrip('G')) if total_disk_output.endswith('G') else 0.0  # Convert to GB
            stdin, stdout, stderr = ssh.exec_command("iostat -d 1 2 | tail -n 1 | awk '{print $3}'")
            disk_read_output = stdout.read().decode().strip()
            disk_read = float(disk_read_output) / 1024 if disk_read_output and disk_read_output.strip() else 0.0
            stdin, stdout, stderr = ssh.exec_command("iostat -d 1 2 | tail -n 1 | awk '{print $4}'")
            disk_write_output = stdout.read().decode().strip()
            disk_write = float(disk_write_output) / 1024 if disk_write_output and disk_write_output.strip() else 0.0

            # Traffic
            stdin, stdout, stderr = ssh.exec_command("vnstat -i ens34 --oneline | cut -d';' -f5")
            traffic_usage_output = stdout.read().decode().strip()
            if traffic_usage_output and "Error" not in traffic_usage_output:
                traffic_value = float(traffic_usage_output.split()[0])
                traffic_unit = traffic_usage_output.split()[1] if len(traffic_usage_output.split()) > 1 else "MB"
                if traffic_unit == "GiB":
                    traffic_usage = traffic_value
                elif traffic_unit == "MiB":
                    traffic_usage = traffic_value / 1024
                elif traffic_unit == "KiB":
                    traffic_usage = traffic_value / (1024 * 1024)
                else:
                    traffic_usage = traffic_value / 1024
                traffic_usage = round(traffic_usage, 3)
            else:
                traffic_usage = 0.0

            # Ping (server ping and agent-to-France ping)
            ping_result = subprocess.run(['ping', '-c', '4', ip], capture_output=True, text=True)
            ping_time = float(ping_result.stdout.split('time=')[1].split()[0]) if 'time=' in ping_result.stdout else 0.0
            # Assuming France server IP is known (replace with actual IP)
            france_ip = "france_server_ip"  # Replace with actual France server IP
            ping_france_result = subprocess.run(['ping', '-c', '4', france_ip], capture_output=True, text=True)
            ping_france_time = float(ping_france_result.stdout.split('time=')[1].split()[0]) if 'time=' in ping_france_result.stdout else 0.0

            ssh.close()
            logging.info("SSH connection closed successfully")

            return jsonify({
                'total_cpu': total_cpu,
                'cpu_usage': cpu_usage,
                'total_ram': total_ram,
                'ram_usage': ram_usage,
                'upload': upload,
                'download': download,
                'total_network': total_network,
                'total_disk': total_disk,
                'disk_read': round(disk_read, 2),
                'disk_write': round(disk_write, 2),
                'traffic_limit': traffic_limit,
                'traffic_usage': traffic_usage,
                'ping_time': ping_time,
                'ping_france_time': ping_france_time
            })
        except Exception as e:
            logging.error(f"Error monitoring server {ip}: {str(e)}")
            return jsonify({'error': str(e)}), 500
    logging.warning(f"Server ID {server_id} not found")
    return jsonify({'error': 'Server not found'}), 404

# Telegram bot handlers
async def start(update, context):
    await context.bot.send_message(chat_id=update.message.chat_id, text="Bot is working!")
    keyboard = [[InlineKeyboardButton("Server List", callback_data='list_servers')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text('Welcome! Choose an option:', reply_markup=reply_markup)

async def button(update, context):
    query = update.callback_query
    await query.answer()
    chat_id = query.message.chat_id

    if query.data == 'list_servers':
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        if str(chat_id) == ADMIN_CHAT_ID:
            c.execute("SELECT id, ip FROM servers WHERE active=1")
            servers = c.fetchall()
        else:
            c.execute("SELECT s.id, s.ip FROM servers s JOIN user_servers us ON s.id = us.server_id JOIN users u ON us.user_id = u.id WHERE u.telegram_chat_id=? AND s.active=1", (str(chat_id),))
            servers = c.fetchall()
        conn.close()

        if not servers:
            await query.edit_message_text("No servers assigned to you.")
            return

        keyboard = [[InlineKeyboardButton(f"Server {ip}", callback_data=f"server_{id}")] for id, ip in servers]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text('Select a server:', reply_markup=reply_markup)

    elif query.data.startswith('server_'):
        server_id = int(query.data.split('_')[1])
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("SELECT ip FROM servers WHERE id=?", (server_id,))
        server = c.fetchone()
        conn.close()
        ip = server[0]

        keyboard = [
            [InlineKeyboardButton("Server Status", callback_data=f"status_{server_id}")],
            [InlineKeyboardButton("Traffic", callback_data=f"traffic_{server_id}")],
            [InlineKeyboardButton("Back", callback_data='list_servers')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(f"Server {ip} options:", reply_markup=reply_markup)

    elif query.data.startswith('status_'):
        server_id = int(query.data.split('_')[1])
        status = get_server_status(server_id)
        await query.edit_message_text(status, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back", callback_data=f"server_{server_id}")]]))

    elif query.data.startswith('traffic_'):
        server_id = int(query.data.split('_')[1])
        traffic = get_server_traffic(server_id)
        await query.edit_message_text(traffic, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back", callback_data=f"server_{server_id}")]]))

def get_server_status(server_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT ip, username, password FROM servers WHERE id=?", (server_id,))
    server = c.fetchone()
    conn.close()
    if server:
        ip, username, password = server
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(ip, username=username, password=password, timeout=10)
            stdin, stdout, stderr = ssh.exec_command("uptime")
            uptime = stdout.read().decode().strip()
            ssh.close()
            return f"Server {ip} is up.\nUptime: {uptime}"
        except Exception as e:
            return f"Server {ip} is down or unreachable: {str(e)}"
    return "Server not found."

def get_server_traffic(server_id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT ip, username, password, traffic_limit FROM servers WHERE id=?", (server_id,))
    server = c.fetchone()
    conn.close()
    if server:
        ip, username, password, traffic_limit = server
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(ip, username=username, password=password, timeout=10)
            stdin, stdout, stderr = ssh.exec_command("vnstat -i ens34 --oneline | cut -d';' -f5")
            traffic_usage_output = stdout.read().decode().strip()
            ssh.close()
            if traffic_usage_output and "Error" not in traffic_usage_output:
                traffic_value = float(traffic_usage_output.split()[0])
                traffic_unit = traffic_usage_output.split()[1] if len(traffic_usage_output.split()) > 1 else "MB"
                if traffic_unit == "GiB":
                    traffic_usage = traffic_value
                elif traffic_unit == "MiB":
                    traffic_usage = traffic_value / 1024
                elif traffic_unit == "KiB":
                    traffic_usage = traffic_value / (1024 * 1024)
                else:
                    traffic_usage = traffic_value / 1024
                traffic_usage = round(traffic_usage, 3)
                return f"Server {ip} traffic usage: {traffic_usage} GB\nLimit: {traffic_limit if traffic_limit > 0 else 'Unlimited'} GB"
            return f"Server {ip} traffic data unavailable."
        except Exception as e:
            return f"Server {ip} error: {str(e)}"
    return "Server not found."

# Background monitoring for server status and traffic
def monitor_servers(application):
    traffic_alerts = {server_id: set() for server_id in range(1, 100)}  # Track sent alerts
    while True:
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("SELECT id, ip, username, password, traffic_limit, telegram_chat_id FROM servers WHERE active=1")
        servers = c.fetchall()
        conn.close()

        for server in servers:
            server_id, ip, username, password, traffic_limit, telegram_chat_id = server
            try:
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.connect(ip, username=username, password=password, timeout=10)
                stdin, stdout, stderr = ssh.exec_command("vnstat -i ens34 --oneline | cut -d';' -f5")
                traffic_usage_output = stdout.read().decode().strip()
                if traffic_usage_output and "Error" not in traffic_usage_output:
                    traffic_value = float(traffic_usage_output.split()[0])
                    traffic_unit = traffic_usage_output.split()[1] if len(traffic_usage_output.split()) > 1 else "MB"
                    if traffic_unit == "GiB":
                        traffic_usage = traffic_value
                    elif traffic_unit == "MiB":
                        traffic_usage = traffic_value / 1024
                    elif traffic_unit == "KiB":
                        traffic_usage = traffic_value / (1024 * 1024)
                    else:
                        traffic_usage = traffic_value / 1024
                    traffic_usage = round(traffic_usage, 3)
                    if traffic_limit > 0:
                        usage_percent = (traffic_usage / traffic_limit) * 100
                        thresholds = [80, 90, 95]
                        for threshold in thresholds:
                            if usage_percent >= threshold and threshold not in traffic_alerts[server_id]:
                                message = f"Server {ip} has consumed {usage_percent:.1f}% of its traffic."
                                application.bot.send_message(telegram_chat_id, message)
                                application.bot.send_message(ADMIN_CHAT_ID, message)
                                send_email(f"Traffic Alert for {ip}", message)
                                traffic_alerts[server_id].add(threshold)
                        # Shutdown if traffic exceeds limit
                        if traffic_usage > traffic_limit:
                            logging.info(f"Server {ip} exceeded traffic limit ({traffic_usage} > {traffic_limit} GB). Shutting down...")
                            stdin, stdout, stderr = ssh.exec_command("sudo shutdown -h now")
                            shutdown_output = stdout.read().decode().strip()
                            shutdown_error = stderr.read().decode().strip()
                            if shutdown_error:
                                logging.error(f"Shutdown failed for {ip}: {shutdown_error}")
                            else:
                                logging.info(f"Server {ip} shutdown initiated: {shutdown_output}")
                            message = f"Server {ip} exceeded traffic limit ({traffic_usage} GB > {traffic_limit} GB) and has been shut down."
                            application.bot.send_message(telegram_chat_id, message)
                            application.bot.send_message(ADMIN_CHAT_ID, message)
                            send_email(f"Server Shutdown: {ip}", message)
                ssh.close()
            except paramiko.AuthenticationException as e:
                if telegram_chat_id:
                    message = f"Server {ip} authentication failed: {str(e)}"
                    application.bot.send_message(telegram_chat_id, message)
                    application.bot.send_message(ADMIN_CHAT_ID, message)
                    send_email(f"Authentication Failed: {ip}", message)
            except paramiko.SSHException as e:
                if "Connection" in str(e) or "timeout" in str(e):
                    if telegram_chat_id:
                        message = f"Server {ip} is down or unreachable!"
                        application.bot.send_message(telegram_chat_id, message)
                        application.bot.send_message(ADMIN_CHAT_ID, message)
                        send_email(f"Server Down: {ip}", message)
                elif "closed by remote host" in str(e):
                    if telegram_chat_id:
                        message = f"Server {ip} has rebooted!"
                        application.bot.send_message(telegram_chat_id, message)
                        application.bot.send_message(ADMIN_CHAT_ID, message)
                        send_email(f"Server Reboot: {ip}", message)
            except Exception as e:
                logging.error(f"Unexpected error monitoring server {ip}: {str(e)}")
        time.sleep(5)  # Check every 5 seconds

# Run Flask in a separate thread
def run_flask():
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)

# Main execution
if __name__ == '__main__':
    init_db()
    application = Application.builder().token(TELEGRAM_TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button))

    # Start Flask in a separate thread
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()

    # Start Telegram bot and monitoring
    threading.Thread(target=monitor_servers, args=(application,), daemon=True).start()
    application.run_polling()
