from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
from functools import wraps
import paramiko
import logging
import threading
import time
import subprocess
import smtplib
from email.mime.text import MIMEText
import redis
import pickle
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler
import datetime
import os
import json
import random
from dotenv import load_dotenv
import asyncio

# بارگذاری متغیرهای محیطی
load_dotenv()

app = Flask(__name__)

# تنظیمات لاگ
logging.basicConfig(filename='app.log', level=logging.DEBUG,
                    format='%(asctime)s %(levelname)s: %(message)s')

# Redis cache
cache = redis.Redis(host='localhost', port=6379, db=0)

# تنظیمات پیش‌فرض
DEFAULT_ENV = {
    "SECRET_KEY": "mysecretkey123",
    "TELEGRAM_TOKEN": "your_BOT_Token",
    "ADMIN_CHAT_ID": "Your_chat_ID",
    "EMAIL_FROM": "your_email@example.com",
    "EMAIL_PASSWORD": "your_password",
    "SMTP_SERVER": "smtp.example.com",
    "SMTP_PORT": "587",
    "DB_PASSWORD": "mypassword",
    "OWNER_PASSWORD": "M801009m780526#"
}

# ساخت فایل .env اگه وجود نداشته باشه
if not os.path.exists('.env'):
    with open('.env', 'w') as f:
        for key, value in DEFAULT_ENV.items():
            f.write(f"{key}={value}\n")
    logging.info("فایل .env با مقادیر پیش‌فرض ساخته شد.")

# بارگذاری دوباره متغیرها بعد از ساخت .env
load_dotenv()

app.secret_key = os.getenv('SECRET_KEY')
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
ADMIN_CHAT_ID = os.getenv('ADMIN_CHAT_ID')
EMAIL_FROM = os.getenv('EMAIL_FROM')
EMAIL_PASSWORD = os.getenv('EMAIL_PASSWORD')
SMTP_SERVER = os.getenv('SMTP_SERVER')
SMTP_PORT = int(os.getenv('SMTP_PORT'))
CONFIG_FILE = "config.json"
DB_PASSWORD = os.getenv('DB_PASSWORD')

# اتصال دیتابیس بدون اتصال سراسری
def get_db_connection():
    conn = sqlite3.connect('database.db', check_same_thread=False)
    conn.execute(f"PRAGMA key='{DB_PASSWORD}'")
    return conn

# مقداردهی دیتابیس
def init_db():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT, telegram_chat_id TEXT, active INTEGER DEFAULT 1)''')
    c.execute('''CREATE TABLE IF NOT EXISTS servers
                 (id INTEGER PRIMARY KEY, name TEXT, ip TEXT, username TEXT, password TEXT, traffic_limit INTEGER DEFAULT 0, telegram_chat_id TEXT, active INTEGER DEFAULT 1, traffic_usage REAL DEFAULT 0)''')
    c.execute('''CREATE TABLE IF NOT EXISTS user_servers
                 (user_id INTEGER, server_id INTEGER)''')
    c.execute('''CREATE TABLE IF NOT EXISTS licenses
                 (id INTEGER PRIMARY KEY, license_key TEXT UNIQUE, expiry_date TEXT, trial_active INTEGER DEFAULT 0)''')
    OWNER_PASSWORD = os.getenv('OWNER_PASSWORD')
    c.execute("INSERT OR IGNORE INTO users (username, password, role, telegram_chat_id, active) VALUES (?, ?, ?, ?, ?)",
              ('marmmr', OWNER_PASSWORD, 'owner', '5961740775', 1))
    c.execute("INSERT OR IGNORE INTO users (username, password, role, telegram_chat_id, active) VALUES (?, ?, ?, ?, ?)",
              ('admin', 'admin123', 'admin', '5961740775', 1))
    conn.commit()
    conn.close()

# ثبت لایسنس 5 روزه پیش‌فرض
def init_default_license():
    if not os.path.exists(CONFIG_FILE):
        default_license_key = "DEFAULT_5_DAY_LICENSE"
        expiry_date = (datetime.datetime.now() + datetime.timedelta(days=5)).strftime("%Y-%m-%d")
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("INSERT OR IGNORE INTO licenses (license_key, expiry_date, trial_active) VALUES (?, ?, 1)",
                  (default_license_key, expiry_date))
        conn.commit()
        conn.close()
        with open(CONFIG_FILE, 'w') as f:
            json.dump({
                "license_key": default_license_key,
                "register_date": datetime.datetime.now().strftime("%Y-%m-%d"),
                "is_trial": True
            }, f)
        logging.info("لایسنس 5 روزه پیش‌فرض ثبت شد.")

# تابع ارسال ایمیل
def send_email(subject, body, to_email='admin@example.com'):
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = EMAIL_FROM
    msg['To'] = to_email
    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(EMAIL_FROM, EMAIL_PASSWORD)
            server.send_message(msg)
            logging.info(f"Email sent to {to_email}: {subject}")
    except Exception as e:
        logging.error(f"Failed to send email: {str(e)}")

# دکوراتورها
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if session['role'] not in ['admin', 'owner']:
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def owner_required(f):
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if session['role'] != 'owner':
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

# تابع محاسبه زمان باقی‌مونده
def get_remaining_time():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            config = json.load(f)
            license_key = config.get("license_key")
            register_date = datetime.datetime.strptime(config['register_date'], "%Y-%m-%d")
            is_trial = config.get("is_trial", False)
            if is_trial:
                days_total = 5
            else:
                days_total = 30  # اینجا می‌تونه هر مقداری باشه که توی لایسنس ثبت شده
            expiry_date = register_date + datetime.timedelta(days=days_total)
            time_left = expiry_date - datetime.datetime.now()
            if time_left.total_seconds() <= 0:
                return {'days': 0, 'hours': 0, 'minutes': 0, 'seconds': 0}, is_trial
            days = time_left.days
            hours, remainder = divmod(time_left.seconds, 3600)
            minutes, seconds = divmod(remainder, 60)
            return {'days': days, 'hours': hours, 'minutes': minutes, 'seconds': seconds}, is_trial
    else:
        init_default_license()
        return {'days': 5, 'hours': 0, 'minutes': 0, 'seconds': 0}, True

# بررسی لایسنس و تایمر
def startup_check():
    time_left, is_trial = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds > 0 or session.get('role') == 'owner':
        mode = "trial" if is_trial else "license"
        logging.info(f"زمان باقی‌مونده: {time_left['days']} روز، {time_left['hours']} ساعت، {time_left['minutes']} دقیقه، {time_left['seconds']} ثانیه ({mode})")
        return True
    else:
        logging.error("لایسنس منقضی شده یا دوره آزمایشی تمام شده است.")
        return False

# صفحه ورود
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=? AND active=1", (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['user_id'] = user[0]
            session['role'] = user[3]
            session['username'] = user[1]
            logging.info(f"کاربر {username} با موفقیت وارد شد.")
            return redirect(url_for('dashboard'))
        else:
            logging.error(f"ورود ناموفق برای {username}")
            return "نام کاربری یا رمز عبور اشتباه است!", 401
    return render_template('login.html')

# خروج
@app.route('/logout')
@login_required
def logout():
    session.pop('user_id', None)
    session.pop('role', None)
    session.pop('username', None)
    return redirect(url_for('login'))

# پروفایل
@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        telegram_chat_id = request.form['telegram_chat_id']
        password = request.form['password']
        conn = get_db_connection()
        c = conn.cursor()
        if session['role'] != 'owner' or session['username'] != 'marmmr':
            c.execute("UPDATE users SET telegram_chat_id=?, password=? WHERE id=?",
                      (telegram_chat_id, password, session['user_id']))
            conn.commit()
        conn.close()
        return redirect(url_for('dashboard'))
    return render_template('profile.html')

# داشبورد
@app.route('/dashboard')
@login_required
def dashboard():
    time_left, is_trial = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        if session['role'] == 'admin':
            return render_template('admin_expired.html')
        else:
            return render_template('user_expired.html')
    
    cached_servers = cache.get('servers')
    if cached_servers:
        servers = pickle.loads(cached_servers)
    else:
        conn = get_db_connection()
        c = conn.cursor()
        if session['role'] in ['admin', 'owner']:
            c.execute("SELECT id, name, ip FROM servers WHERE active=1")
            servers = [(row[0], row[1], row[2]) for row in c.fetchall()]
        else:
            c.execute("SELECT s.id, s.name, s.ip FROM servers s JOIN user_servers us ON s.id = us.server_id WHERE us.user_id=? AND s.active=1",
                      (session['user_id'],))
            servers = [(row[0], row[1], row[2]) for row in c.fetchall()]
        conn.commit()
        conn.close()
        cache.setex('servers', 300, pickle.dumps(servers))
    return render_template('dashboard.html', servers=servers, role=session['role'], time_left=time_left, is_trial=is_trial)

# داشبورد ادمین
@app.route('/admin_dashboard')
@admin_required
def admin_dashboard():
    time_left, is_trial = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        return render_template('admin_expired.html')
    return render_template('admin_dashboard.html', time_left=time_left, is_trial=is_trial)

# اضافه کردن سرور
@app.route('/add_server', methods=['GET', 'POST'])
@admin_required
def add_server_page():
    time_left, _ = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        return render_template('admin_expired.html')
    if request.method == 'POST':
        name = request.form['name']
        ip = request.form['ip']
        username = request.form['username']
        password = request.form['password']
        traffic_limit = request.form.get('traffic_limit', 0)
        telegram_chat_id = request.form.get('telegram_chat_id', '')
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("INSERT INTO servers (name, ip, username, password, traffic_limit, telegram_chat_id, active, traffic_usage) VALUES (?, ?, ?, ?, ?, ?, 1, 0)",
                  (name, ip, username, password, traffic_limit, telegram_chat_id))
        conn.commit()
        conn.close()
        cache.delete('servers')
        return redirect(url_for('admin_dashboard'))
    return render_template('add_server.html')

# اضافه کردن کاربر
@app.route('/add_user', methods=['GET', 'POST'])
@admin_required
def add_user_page():
    time_left, _ = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        return render_template('admin_expired.html')
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        telegram_chat_id = request.form.get('telegram_chat_id', '')
        if role != 'owner':
            conn = get_db_connection()
            c = conn.cursor()
            c.execute("INSERT INTO users (username, password, role, telegram_chat_id, active) VALUES (?, ?, ?, ?, 1)",
                      (username, password, role, telegram_chat_id))
            conn.commit()
            conn.close()
        return redirect(url_for('admin_dashboard'))
    return render_template('add_user.html')

# اختصاص سرور
@app.route('/assign_server', methods=['GET', 'POST'])
@admin_required
def assign_server_page():
    time_left, _ = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        return render_template('admin_expired.html')
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT id, username FROM users WHERE active=1 AND username != 'marmmr'")
    users = c.fetchall()
    c.execute("SELECT id, name FROM servers WHERE active=1")
    servers = c.fetchall()
    if request.method == 'POST':
        user_id = request.form['user_id']
        server_id = request.form['server_id']
        c.execute("INSERT OR IGNORE INTO user_servers (user_id, server_id) VALUES (?, ?)", (user_id, server_id))
        conn.commit()
        conn.close()
        cache.delete('servers')
        return redirect(url_for('admin_dashboard'))
    conn.close()
    return render_template('assign_server.html', users=users, servers=servers)

# مدیریت سرورها
@app.route('/manage_servers', methods=['GET', 'POST'])
@admin_required
def manage_servers():
    time_left, _ = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        return render_template('admin_expired.html')
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM servers")
    servers = c.fetchall()
    if request.method == 'POST' and 'edit_server_id' in request.form:
        server_id = request.form['edit_server_id']
        name = request.form['name']
        ip = request.form['ip']
        username = request.form['username']
        password = request.form['password']
        traffic_limit = request.form.get('traffic_limit', 0)
        telegram_chat_id = request.form.get('telegram_chat_id', '')
        c.execute("UPDATE servers SET name=?, ip=?, username=?, password=?, traffic_limit=?, telegram_chat_id=? WHERE id=?",
                  (name, ip, username, password, traffic_limit, telegram_chat_id, server_id))
        conn.commit()
        conn.close()
        cache.delete('servers')
        return redirect(url_for('manage_servers'))
    conn.close()
    return render_template('manage_servers.html', servers=servers)

# ریست ترافیک
@app.route('/reset_traffic/<int:server_id>')
@admin_required
def reset_traffic(server_id):
    time_left, _ = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        return render_template('admin_expired.html')
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT ip, username, password FROM servers WHERE id=?", (server_id,))
    server = c.fetchone()
    if server:
        ip, username, password = server
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(ip, username=username, password=password, timeout=10)
            ssh.exec_command("vnstat -i ens34 --reset")
            ssh.close()
            logging.info(f"Traffic reset for server {ip}")
        except Exception as e:
            logging.error(f"Failed to reset traffic for {ip}: {str(e)}")
    c.execute("UPDATE servers SET traffic_usage=0 WHERE id=?", (server_id,))
    conn.commit()
    conn.close()
    cache.delete('servers')
    return redirect(url_for('manage_servers'))

# مدیریت کاربران
@app.route('/manage_users', methods=['GET', 'POST'])
@admin_required
def manage_users():
    time_left, _ = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        return render_template('admin_expired.html')
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT id, username, role, telegram_chat_id, active FROM users WHERE username != 'marmmr'")
    users = c.fetchall()
    if request.method == 'POST' and 'edit_user_id' in request.form:
        user_id = request.form['edit_user_id']
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        telegram_chat_id = request.form.get('telegram_chat_id', '')
        if role != 'owner' and username != 'marmmr':
            c.execute("UPDATE users SET username=?, password=?, role=?, telegram_chat_id=? WHERE id=?",
                      (username, password, role, telegram_chat_id, user_id))
            conn.commit()
        conn.close()
        return redirect(url_for('manage_users'))
    conn.close()
    return render_template('manage_users.html', users=users)

# تغییر وضعیت سرور
@app.route('/toggle_server/<int:server_id>')
@admin_required
def toggle_server(server_id):
    time_left, _ = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        return render_template('admin_expired.html')
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT active FROM servers WHERE id=?", (server_id,))
    current_status = c.fetchone()[0]
    new_status = 0 if current_status == 1 else 1
    c.execute("UPDATE servers SET active=? WHERE id=?", (new_status, server_id))
    conn.commit()
    conn.close()
    cache.delete('servers')
    return redirect(url_for('manage_servers'))

# حذف کاربر
@app.route('/delete_user/<int:user_id>')
@admin_required
def delete_user(user_id):
    time_left, _ = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        return render_template('admin_expired.html')
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT username FROM users WHERE id=?", (user_id,))
    user = c.fetchone()
    if user and user[0] != 'marmmr':
        c.execute("DELETE FROM users WHERE id=?", (user_id,))
        c.execute("DELETE FROM user_servers WHERE user_id=?", (user_id,))
        conn.commit()
    conn.close()
    return redirect(url_for('manage_users'))

# تغییر وضعیت کاربر
@app.route('/toggle_user/<int:user_id>')
@admin_required
def toggle_user(user_id):
    time_left, _ = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        return render_template('admin_expired.html')
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT active, username FROM users WHERE id=?", (user_id,))
    result = c.fetchone()
    if result and result[1] != 'marmmr':
        current_status = result[0]
        new_status = 0 if current_status == 1 else 1
        c.execute("UPDATE users SET active=? WHERE id=?", (new_status, user_id))
        conn.commit()
    conn.close()
    return redirect(url_for('manage_users'))

# مانیتورینگ سرور
@app.route('/live/<int:server_id>')
@login_required
def live_port(server_id):
    time_left, _ = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        if session['role'] == 'admin':
            return render_template('admin_expired.html')
        else:
            return render_template('user_expired.html')
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT ip, username, password, traffic_limit FROM servers WHERE id=?", (server_id,))
    server = c.fetchone()
    conn.close()
    if server:
        return render_template('live_port.html', server_id=server_id)
    return "Server not found", 404

# داده‌های مانیتورینگ
@app.route('/monitor/<int:server_id>')
@login_required
def monitor_server(server_id):
    time_left, _ = get_remaining_time()
    total_seconds = time_left['days'] * 86400 + time_left['hours'] * 3600 + time_left['minutes'] * 60 + time_left['seconds']
    if total_seconds <= 0 and session['role'] != 'owner':
        if session['role'] == 'admin':
            return render_template('admin_expired.html')
        else:
            return render_template('user_expired.html')
    logging.info(f"Request received for monitoring server ID: {server_id}")
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT ip, username, password, traffic_limit, telegram_chat_id FROM servers WHERE id=?", (server_id,))
    server = c.fetchone()
    if server:
        ip, username, password, traffic_limit, telegram_chat_id = server
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(ip, username=username, password=password, timeout=10)
            command = (
                "nproc && "
                "top -bn1 | grep 'Cpu(s)' | awk '{print $2}' && "
                "free -m | awk '/Mem:/ {print $2}' && "
                "free -m | awk '/Mem:/ {print $3/$2 * 100}' && "
                "vnstat -tr 2 -i ens34 | grep 'rx' | awk '{print $2}' && "
                "vnstat -tr 2 -i ens34 | grep 'tx' | awk '{print $2}' && "
                "df -h / | awk 'NR==2 {print $2}' && "
                "iostat -d 1 2 | tail -n 1 | awk '{print $3}' && "
                "iostat -d 1 2 | tail -n 1 | awk '{print $4}' && "
                "vnstat -m -i ens34 | grep 'estimated' | awk '{print $8}'"
            )
            stdin, stdout, stderr = ssh.exec_command(command)
            output = stdout.read().decode().strip().split('\n')
            total_cpu = int(output[0]) if output[0] else 0
            cpu_usage = float(output[1]) if output[1] else 0.0
            total_ram = int(output[2]) if output[2] else 0
            ram_usage = float(output[3]) if output[3] else 0.0
            download = float(output[4]) / 8 if output[4] else 0.0
            upload = float(output[5]) / 8 if output[5] else 0.0
            total_network = upload + download
            total_disk = float(output[6].rstrip('G')) if output[6] else 0.0
            disk_read = float(output[7]) / 1024 if output[7] else 0.0
            disk_write = float(output[8]) / 1024 if output[8] else 0.0
            traffic_usage_str = output[9].rstrip('GiB') if output[9] else '0'
            traffic_usage = float(traffic_usage_str) if traffic_usage_str else 0.0

            server_shutdown = False
            if traffic_limit > 0 and traffic_usage > traffic_limit:
                ssh.exec_command("sudo shutdown -h now")
                message = f"Server {ip} exceeded traffic limit ({traffic_usage} GB > {traffic_limit} GB) and shut down."
                logging.info(message)
                send_email(f"Server Shutdown: {ip}", message)
                server_shutdown = True

            ping_result = subprocess.run(['ping', '-c', '4', ip], capture_output=True, text=True)
            ping_time = float(ping_result.stdout.split('time=')[1].split()[0]) if 'time=' in ping_result.stdout else 0.0
            ssh.close()

            c.execute("UPDATE servers SET traffic_usage=? WHERE id=?", (traffic_usage, server_id))
            conn.commit()
            conn.close()

            data = {
                'total_cpu': total_cpu,
                'cpu_usage': cpu_usage,
                'total_ram': total_ram,
                'ram_usage': ram_usage,
                'upload': upload,
                'download': download,
                'total_network': total_network,
                'total_disk': total_disk,
                'disk_read': disk_read,
                'disk_write': disk_write,
                'traffic_limit': traffic_limit,
                'traffic_usage': traffic_usage,
                'ping_time': ping_time,
                'ping_france_time': 0.0,
                'server_status': 'shutdown' if server_shutdown else 'active'
            }
            logging.debug(f"Monitoring data for server {server_id}: {data}")
            return jsonify(data)
        except Exception as e:
            conn.close()
            error_msg = str(e)
            logging.error(f"Error monitoring server {ip}: {error_msg}")
            return jsonify({
                'error': error_msg,
                'server_status': 'offline'
            }), 500
    conn.close()
    return jsonify({'error': 'Server not found'}), 404

# تولید لایسنس
@app.route('/generate_license', methods=['GET', 'POST'])
@owner_required
def generate_license():
    if request.method == 'POST':
        days_valid = int(request.form.get('days_valid', 365))  # تعداد روز از فرم
        license_key = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=16))
        expiry_date = (datetime.datetime.now() + datetime.timedelta(days=days_valid)).strftime("%Y-%m-%d")
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("INSERT INTO licenses (license_key, expiry_date, trial_active) VALUES (?, ?, 0)", (license_key, expiry_date))
        conn.commit()
        c.execute("SELECT license_key, expiry_date FROM licenses WHERE license_key=?", (license_key,))
        stored = c.fetchone()
        if stored:
            logging.info(f"لایسنس {license_key} با موفقیت در دیتابیس ذخیره شد با انقضای {stored[1]} ({days_valid} روز)")
        else:
            logging.error(f"خطا در ذخیره‌سازی لایسنس {license_key} در دیتابیس")
        conn.close()
        return render_template('generate_license.html', license_key=license_key, days_valid=days_valid)
    return render_template('generate_license.html')

# ثبت لایسنس
@app.route('/register_license', methods=['GET', 'POST'])
@login_required
def register_license():
    if session['role'] not in ['admin', 'owner']:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        license_key = request.form['license_key']
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("SELECT license_key, expiry_date, trial_active FROM licenses WHERE license_key=?", (license_key,))
        result = c.fetchone()
        if result:
            db_license_key, expiry_date, trial_active = result
            current_date = time.strftime("%Y-%m-%d")
            logging.debug(f"لایسنس پیدا شده: {license_key}, انقضا: {expiry_date}, فعلی: {current_date}, trial: {trial_active}")
            if expiry_date > current_date:
                with open(CONFIG_FILE, 'w') as f:
                    json.dump({
                        "license_key": license_key,
                        "register_date": datetime.datetime.now().strftime("%Y-%m-%d"),
                        "is_trial": trial_active == 1
                    }, f)
                logging.info(f"لایسنس {license_key} ثبت شد. دوره: {'5 روزه' if trial_active else 'ثبت‌شده'}")
                conn.close()
                return redirect(url_for('license_result', license_key=license_key, valid=True))
            else:
                logging.warning(f"لایسنس {license_key} منقضی شده: {expiry_date} <= {current_date}")
        else:
            c.execute("SELECT license_key, expiry_date FROM licenses")
            all_licenses = c.fetchall()
            logging.debug(f"همه لایسنس‌های موجود: {[lic[0] for lic in all_licenses]}")
            logging.warning(f"لایسنس {license_key} در دیتابیس پیدا نشد.")
        conn.close()
        return redirect(url_for('license_result', license_key=license_key, valid=False))
    return render_template('register_license.html')

# صفحه نتیجه ثبت لایسنس
@app.route('/license_result/<license_key>/<valid>')
@login_required
def license_result(license_key, valid):
    valid = valid == 'True'
    time_left, is_trial = get_remaining_time()
    return render_template('license_result.html', license_key=license_key, valid=valid, time_left=time_left, is_trial=is_trial)

# بررسی لایسنس
def check_license(license_key):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT expiry_date, trial_active FROM licenses WHERE license_key=?", (license_key,))
    result = c.fetchone()
    conn.close()
    if result:
        expiry_date, trial_active = result
        current_date = time.strftime("%Y-%m-%d")
        logging.debug(f"بررسی لایسنس: {license_key}, انقضا: {expiry_date}, فعلی: {current_date}, trial: {trial_active}")
        if expiry_date > current_date:
            return True
    logging.warning(f"لایسنس نامعتبر: {license_key}")
    return False

# هندلرهای تلگرام
async def start(update, context):
    await context.bot.send_message(chat_id=update.message.chat_id, text="Bot is working!")
    keyboard = [[InlineKeyboardButton("Server List", callback_data='list_servers')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text('Welcome! Choose an option:', reply_markup=reply_markup)

async def button(update, context):
    query = update.callback_query
    await query.answer()
    chat_id = query.message.chat_id
    if query.data == 'list_servers':
        conn = get_db_connection()
        c = conn.cursor()
        if str(chat_id) == ADMIN_CHAT_ID:
            c.execute("SELECT id, ip FROM servers WHERE active=1")
            servers = c.fetchall()
        else:
            c.execute("SELECT s.id, s.ip FROM servers s JOIN user_servers us ON s.id = us.server_id JOIN users u ON us.user_id = u.id WHERE u.telegram_chat_id=? AND s.active=1", (str(chat_id),))
            servers = c.fetchall()
        conn.close()
        if not servers:
            await query.edit_message_text("No servers assigned to you.")
            return
        keyboard = [[InlineKeyboardButton(f"Server {ip}", callback_data=f"server_{id}")] for id, ip in servers]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text('Select a server:', reply_markup=reply_markup)
    elif query.data.startswith('server_'):
        server_id = int(query.data.split('_')[1])
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("SELECT ip FROM servers WHERE id=?", (server_id,))
        server = c.fetchone()
        conn.close()
        ip = server[0]
        keyboard = [
            [InlineKeyboardButton("Server Status", callback_data=f"status_{server_id}")],
            [InlineKeyboardButton("Traffic", callback_data=f"traffic_{server_id}")],
            [InlineKeyboardButton("Back", callback_data='list_servers')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(f"Server {ip} options:", reply_markup=reply_markup)
    elif query.data.startswith('status_'):
        server_id = int(query.data.split('_')[1])
        status = get_server_status(server_id)
        await query.edit_message_text(status, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back", callback_data=f"server_{server_id}")]]))
    elif query.data.startswith('traffic_'):
        server_id = int(query.data.split('_')[1])
        traffic = get_server_traffic(server_id)
        await query.edit_message_text(traffic, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back", callback_data=f"server_{server_id}")]]))

def get_server_status(server_id):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT ip, username, password FROM servers WHERE id=?", (server_id,))
    server = c.fetchone()
    conn.close()
    if server:
        ip, username, password = server
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(ip, username=username, password=password, timeout=10)
            stdin, stdout, stderr = ssh.exec_command("uptime")
            uptime = stdout.read().decode().strip()
            ssh.close()
            return f"Server {ip} is up.\nUptime: {uptime}"
        except Exception as e:
            return f"Server {ip} is down or unreachable: {str(e)}"
    return "Server not found."

def get_server_traffic(server_id):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT ip, username, password, traffic_limit, traffic_usage FROM servers WHERE id=?", (server_id,))
    server = c.fetchone()
    conn.close()
    if server:
        ip, username, password, traffic_limit, traffic_usage = server
        return f"Server {ip} traffic usage: {traffic_usage} GB\nLimit: {traffic_limit if traffic_limit > 0 else 'Unlimited'} GB"
    return "Server not found."

async def send_telegram_message(bot, chat_id, message):
    await bot.send_message(chat_id=chat_id, text=message)

def monitor_servers(application):
    traffic_alerts = {server_id: set() for server_id in range(1, 100)}
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    while True:
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("SELECT id, ip, username, password, traffic_limit, telegram_chat_id, traffic_usage FROM servers WHERE active=1")
        servers = c.fetchall()
        conn.close()
        for server in servers:
            server_id, ip, username, password, traffic_limit, telegram_chat_id, traffic_usage = server
            time.sleep(random.uniform(0.5, 2.0))
            try:
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.connect(ip, username=username, password=password, timeout=10)
                stdin, stdout, stderr = ssh.exec_command("vnstat -m -i ens34 | grep 'estimated' | awk '{print $8}'")
                traffic_usage_output = stdout.read().decode().strip()
                traffic_usage_new = float(traffic_usage_output.rstrip('GiB')) if traffic_usage_output else 0.0
                conn = get_db_connection()
                c = conn.cursor()
                c.execute("UPDATE servers SET traffic_usage=? WHERE id=?", (traffic_usage_new, server_id))
                conn.commit()
                conn.close()
                if traffic_limit > 0 and traffic_usage_new > traffic_limit:
                    ssh.exec_command("sudo shutdown -h now")
                    message = f"Server {ip} exceeded traffic limit ({traffic_usage_new} GB > {traffic_limit} GB) and shut down."
                    logging.info(message)
                    send_email(f"Server Shutdown: {ip}", message)
                    loop.run_until_complete(send_telegram_message(application.bot, telegram_chat_id, message))
                    loop.run_until_complete(send_telegram_message(application.bot, ADMIN_CHAT_ID, message))
                ssh.close()
            except Exception as e:
                logging.error(f"Error monitoring server {ip}: {str(e)}")
        time.sleep(5)

def run_flask():
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)

if __name__ == '__main__':
    init_db()
    init_default_license()
    if not startup_check():
        print("برنامه غیرفعال شد. لطفاً لایسنس معتبر ثبت کنید.")
        exit(1)
    application = Application.builder().token(TELEGRAM_TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button))
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()
    threading.Thread(target=monitor_servers, args=(application,), daemon=True).start()
    application.run_polling()